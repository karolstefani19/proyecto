from tkinter import*
from math import*
import random
import time
ventana=Tk()
ventana.geometry("700x550+0+0")
ventana.config(bg="white")
ventana.title("Road Fighter")
x=0
y=0
def NuevaVentana1():
    """
    """
    global imagenC1,imagenC2,p,q,canvas1,imagenCarro1,imagenCarro2, imagenCarro7, tecla,ventana1,imagenA,imagenCarro5,imagenC7,imagenC8
    global imagenC,imagenD,imagenB,yA,yB,limite,retroceso,m,n,r,s,imagenCarro3,imagenC3,imagenC4,Fuel1,Fuel2, imagenGo1, imagenGo2,xgo1,ygo1, xgo2,ygo2
    global s,s2, r,w,e, e1,k, k1, k2, k3, k4, k5, k6, m1, q1, puntos,puntos2, imagenEx,imagenEx1,imagenEx2,imagenEx3,imagenEx4,imagenCarro4,imagenC5,imagenC6
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas, imagengo1, imagengo2
    
    ventana1=Toplevel(ventana)
    ventana.iconify()
    ventana1.geometry("1400x520+0+0")
    ventana1.config(bg="white")
    ventana1.title("Road Fighter")
    canvas1 = Canvas(ventana1, width = 1400, height = 550)

    # Se va a crear una imagen
    k = 0 # posicion de carro 1
    k1 = 0 #posición de carro 2
    k2 = 0 #posicion de carro 3
    k3 = 0 # posicion de manchas de aceite
    k4 = 0 # posicion de manchas de aceite
    k5 = 0 # posicion de tanques de gasolina
    k6 = 0 # posicion de tanques de gasolina
    p = 250 #x carro1
    q = 450 #y carro1
    
    q1 = 600 
    n = 900 #y carro2
    m1 = 600 #x carro1
    m = 450 #x carro1

    xm1 = random.randint (230, 380)
    ym1 = 0

    xm2 = random.randint(880,1040) 
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0

    xgo1 = 500
    ygo1 = 265

    xgo2 = 500
    ygo2 = 265
    
    s = random.randint(230,380)
    r = 0
    w = random.randint(880,1040)
    e = 0
    e1 = 290
    yA = 260
    yB = -260
    limite = 785
    retroceso = -1040
    puntos = 0
    puntos2 = 0
    Fuel1 = 10000
    Fuel2 = 10000
    imagenpista = PhotoImage(file="pista1.png")
    imagenA = canvas1.create_image(350,265, image = imagenpista)
    imagenB = canvas1.create_image(350,-260,image = imagenpista)
    imagenC = canvas1.create_image(1000,265, image = imagenpista)
    imagenD = canvas1.create_image(1000,-260,image = imagenpista)
    name = Label(ventana1, text = "Jugador 1:" + entrada1.get(), font = "Arial").place(x = 530, y = 100)
    name1 = Label(ventana1, text = "Jugador 2:" + entrada2.get(),font = "Arial").place(x = 1175, y = 100)
    imagenCarro1 = PhotoImage(file="Carro1.png")
    imagenC1 = canvas1.create_image(p,q, image = imagenCarro1)
    imagenCarro2 = PhotoImage(file="Carro2.png")
    imagenC2 = canvas1.create_image(n,m, image = imagenCarro2)
    
    imagenCarro3 = PhotoImage(file="Carro3.png")
    imagenC3 = canvas1.create_image(s,r, image = imagenCarro3)
    imagenC4 = canvas1.create_image(w,e, image = imagenCarro3)
    
    imagenCarro4 = PhotoImage(file="Carro4.png")
    imagenC5 = canvas1.create_image(s,r, image = imagenCarro4)
    imagenC6 = canvas1.create_image(w,e, image = imagenCarro4)
    
    imagenCarro5 = PhotoImage(file="Carro5.png")
    imagenC7 = canvas1.create_image(p,e1, image = imagenCarro5)
    imagenC8 = canvas1.create_image(n,e1, image = imagenCarro5)
    
    imagenMancha = PhotoImage(file="mancha.png")
    imagenM1 = canvas1.create_image(xm1, ym1, image = imagenMancha)
    imagenM2 = canvas1.create_image(xm2, ym2, image = imagenMancha)

    imagenGas = PhotoImage (file="gasolina.png")
    imagenG1 = canvas1.create_image(xg1, yg1, image = imagenGas)
    imagenG2 = canvas1.create_image(xg2, yg2, image = imagenGas)

##    imagenGo1 = PhotoImage(file="gameover1.png")
##    imagengo1 = canvas1.create_image(xgo1, ygo1, image = imagenGo1)
##    imagenGo2 = PhotoImage(file="gameover2.png")
##    imagengo2 = canvas1.create_image(xgo2, ygo2, image = imagenGo2)
    
    imagenEx = PhotoImage(file="boom.png")
    ventana1.bind("<Key>", key)
    mover()
    moverCarros()
    canvas1.pack()
    
    
    ventana1.mainloop()
    
def mover():
    global ventana1,canvas1,imagenA,imagenB,imagenC,imagenD,yA,yB,limite,retroceso, puntos,puntos2, Fuel1,Fuel2
   
    if(yA>=limite):
        canvas1.move(imagenA,0,retroceso)
        canvas1.move(imagenC,0,retroceso)
        yA+=retroceso
        
    if(yB>=limite):
        canvas1.move(imagenB,0,retroceso)
        canvas1.move(imagenD,0,retroceso)
        yB+=retroceso
    yA+=2
    yB+=2
    puntos += 1
    puntos2 += 1
    puntoJ1 = Label(ventana1, text = "Puntos:" + str(puntos), font = "Arial").place(x = 530, y = 140)
    puntoJ2 = Label(ventana1, text = "Puntos:" + str(puntos2), font = "Arial").place(x = 1175, y = 140)
    FuelJ1 = Label(ventana1, text = "Fuel:" + str(Fuel1), font = "Arial").place(x = 530, y = 200)
    FuelJ2 = Label(ventana1, text = "Fuel:" + str(Fuel2), font = "Arial").place(x = 1175, y = 200)
    canvas1.move(imagenA,0,2) 
    canvas1.move(imagenB,0,2)
    canvas1.move(imagenC,0,2)
    canvas1.move(imagenD,0,2)
    ventana1.after(4, mover)
    if (puntos == 15000):
        #imprimir en pantalla jugador1 gana
        #Cerrar ventana1
        #canvas1.after(500,timee)
        NuevaVentana2()
    if (puntos2 == 15000):
        #imprimir jugador2 gana
        #cerrar ventana1
        NuevaVentana2()

def moverCarros():
    global p, q, n, m, y,ventana1,canvas1,imagenC3,imagenC4,imagenC7,imagenC8,yA,yB,limite,retroceso,w,e,s,r,k,k1,k2,s2,w2,s3,w3,imagenC5,imagenC6,x,Fuel1,Fuel2, imagengo1,imagengo2
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, k3, k4, k5, k6, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas, puntos, puntos2, imagenGo1, imagenGo2

    
    s = random.randint(230,380) #x de carroC3
    w = random.randint(880,1040) #x de carroC4
    s2 = random.randint(230,380) #x de carroC5
    w2 = random.randint(880,1040) #x de carroC6
    s3 = random.randint(250,350) #x de carroC5
    w3 = random.randint(800,1040)

    xm1 = random.randint(230,380)
    ym1 = 0

    xm2 = random.randint(880,1040)
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    if(canvas1.coords(imagenC5)[1] == 890.0):
        canvas1.move(imagenC5,0,-100)
        
    # Enemigo 1
    if (k>400):
        k=0
        imagenC3 = canvas1.create_image(s,r, image = imagenCarro3)
        imagenC4 = canvas1.create_image(w,e, image = imagenCarro3)

    k = k + 2
    canvas1.move(imagenC3,0,4)
    canvas1.move(imagenC4,0,4)

    distxC3C1 = (canvas1.coords(imagenC3)[0] - canvas1.coords(imagenC1)[0])**2
    distyC3C1 = (canvas1.coords(imagenC3)[1] - canvas1.coords(imagenC1)[1])**2
    distEuclC3C1 = sqrt(distxC3C1+distyC3C1)
    
    #print("C3 ", canvas1.coords(imagenC3))
    #print("C1 ", canvas1.coords(imagenC1))
    #print("distx ",  distxC3C1, " disty ",  distyC3C1, "euclidiana ", sqrt(distxC3C1+distyC3C1))
    
    if(distEuclC3C1 <= 55):
        Fuel1 -= 10
       # print("colision ")

    ################ colision 2 ################
    ############################################

    distxC5C1 = (canvas1.coords(imagenC5)[0] - canvas1.coords(imagenC1)[0])**2
    distyC5C1 = (canvas1.coords(imagenC5)[1] - canvas1.coords(imagenC1)[1])**2
    distEuclC5C1 = sqrt(distxC5C1+distyC5C1)
    if (distEuclC5C1 <= 60):
        Fuel1 -= 10
        canvas1.coords(imagenC1)[0] = canvas1.coords(imagenC1)[0] - 10
        
       # print("C5 ", canvas1.coords(imagenC5))
      #  print("C1 ", canvas1.coords(imagenC1))
     #   print("distx ",  distxC5C1, " disty ",  distyC5C1, "euclidiana ", sqrt(distxC5C1+distyC5C1))
    #    print("colision 2")
     #ventana1.after(60, moverCarros)


    # Enemigo 2
    if (k1>565):
        k1=0
        imagenC5 = canvas1.create_image(s2,r, image = imagenCarro4)
        imagenC6 = canvas1.create_image(w2,e, image = imagenCarro4)

    k1 = k1 + 2
    #print(canvas1.coords(imagenC5)[0])
    if(canvas1.coords(imagenC5)[0]== 390.0):
        x=1
    if(canvas1.coords(imagenC5)[0]== 225.0):
        x=0
    if(canvas1.coords(imagenC6)[0]== 1040.0):
        y=1
    if(canvas1.coords(imagenC6)[0]== 873.0):
        y=0
    if(y==0):
        canvas1.move(imagenC6,1,2)
    else:
        canvas1.move(imagenC6,-1,2)        
    if(x==0):
        canvas1.move(imagenC5,1,2)
    else:
        canvas1.move(imagenC5,-1,2)
        canvas1.coords(imagenC6)
    ventana1.after(60, moverCarros)

    # Enemigo 3

    if(k2>580):
        k2 = 0
        imagenC7 = canvas1.create_image(s3,r, image = imagenCarro5)
        imagenC8 = canvas1.create_image(w3,e, image = imagenCarro5)
    k2 = k2 + 2
        
    canvas1.move(imagenC7,0,2)
    canvas1.move(imagenC8,0,2)
    #print(canvas1.coords(imagenC7)[1])
#    if(canvas1.coords(imagenC7)[1] > 620.0):
        #print("coso")
 #       canvas1.move(imagenC7,0,2)
        
    #if(canvas1.coords(imagenC7)[1]==canvas1.coords(imagenC1)[1]):
      #  canvas1.move(imagenC7,0,canvas1.coords(imagenC7)[1])



    #manchas de aceite quitan puntos y gasolina 
    if (k3 > 500):
        k3 = 0
        imagenM1 = canvas1.create_image(xm1, ym1, image = imagenMancha)

    k3 = k3 + 2
    canvas1.move (imagenM1, 0, 3)

    #colision con aceite player 1
    ##########################
    distxM1C1 = (canvas1.coords(imagenM1)[0] - canvas1.coords(imagenC1)[0])**2
    distyM1C1 = (canvas1.coords(imagenM1)[1] - canvas1.coords(imagenC1)[1])**2
    distEuclM1C1 = sqrt(distxM1C1+distyM1C1)
    if (distEuclM1C1 <= 60):
        Fuel1 -= 100
        puntos -= 10
        canvas1.move(imagenC1, 1, 1)
        p = p + 1
        
        
    if(k4 > 500):
        k4 = 0
        imagenM2 = canvas1.create_image(xm2, ym2, image = imagenMancha)
    k4 = k4 + 2
    canvas1.move (imagenM2,0,3)

    #colision con aceite player 2
    #############################
    distxM2C2 = (canvas1.coords(imagenM2)[0] - canvas1.coords(imagenC2)[0])**2
    distyM2C2 = (canvas1.coords(imagenM2)[1] - canvas1.coords(imagenC2)[1])**2
    distEuclM2C2 = sqrt(distxM2C2+distyM2C2)
    if (distEuclM2C2 <= 60):
        Fuel2 -= 100
        puntos2 -= 10
        canvas1.move(imagenC2, 1, 1)
        n = n + 1

    #gasolina
    if (k5 > 400):
        k5 = 0
        imagenG1 = canvas1.create_image(xg1, yg1, image = imagenGas)
    k5 = k5 + 2
    canvas1.move (imagenG1, 0, 3)

    #colision con gasolina player 1
    ##########################
    distxG1C1 = (canvas1.coords(imagenG1)[0] - canvas1.coords(imagenC1)[0])**2
    distyG1C1 = (canvas1.coords(imagenG1)[1] - canvas1.coords(imagenC1)[1])**2
    distEuclG1C1 = sqrt(distxG1C1+distyG1C1)
    if (distEuclG1C1 <= 60):
        Fuel1 += 250
        k5 = 400
        canvas1.delete(imagenG1)
    
    if (k6 > 400):
        k6 = 0
        imagenG2 = canvas1.create_image(xg2, yg2, image = imagenGas)
    k6 = k6 + 2
    canvas1.move(imagenG2, 0, 3)

    if (Fuel1 == 0):
        #imagen gameover gana jugador 2
        imagengo2 = canvas1.create_image(xgo2, ygo2, image = imagenGo2)
        print ("jugador2")

    if (Fuel2 == 0):
        #imagen gameover gana jugador 1
        imagengo1 = canvas1.create_image(xgo1, ygo1, image = imagenGo1)
        print("jugador1")

    
def key(event):
    """
    """
    global e1,imagenC1,imagenC2,imagenC3,imagenC7,imagenCarro5,p,q,m,n,canvas1,imagenCarro1,tecla,ventana1,imagenCarro2,imagenEx,limite,w,q1,imagenC7,Fuel1,Fuel2
    tecla = repr(event.char)

    if(tecla == "'w'"):
        Fuel1 -= 10
        if(q < 500): 
            canvas1.delete(imagenC1)
            q = q - 10
            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)

    if(tecla == "'s'"):
        Fuel1 -= 10
        if(q > 0): 
            canvas1.delete(imagenC1)
            q = q + 10
            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)

    if(tecla == "'d'"):
        Fuel1 -= 10
        canvas1.move(imagenC7,5,0)
        if(p < 380):
            canvas1.delete(imagenC1)
            #canvas1.delete(imagenC7)
            p = p + 10
            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)
            #imagenC7 = canvas1.create_image(p,e1,image=imagenCarro5)
            if (p == 380):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(380,q,image=imagenEx)
##                ventana1.after(200,timee)             
##        else:
##            canvas1.delete(imagenC1)
##            p = p - 10
##            imagenC1 = canvas1.create_image(p,q, image=imagenCarro1)
##            

    if(tecla == "'a'"):
        Fuel1 -= 10
        canvas1.move(imagenC7,-5,0)
        if(p > 230):
            canvas1.delete(imagenC1)
            p = p - 10
            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)
            if ( p == 230):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(230,q,image=imagenEx)
##                ventana1.after(1,timee)
##                canvas1.delete(imagenEx)
                
##        else:
##            canvas1.delete(imagenC1)
##            p = p + 10
##            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)

    if(tecla == "'y'"):
        Fuel2 -= 10
        if(m < 500):
            canvas1.delete(imagenC2)
            m = m - 10
            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

    if(tecla == "'h'"):
        Fuel2 -= 10
        if(m > 0):
            canvas1.delete(imagenC2)
            m = m + 10
            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

    if(tecla == "'g'"):
        if(n > 880):
            canvas1.delete(imagenC2)
            n = n - 10
            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)
            if(p==880):
                canvas1.delete(imagenC2)
                imagenEx1 = canvas1.create_image(880,q,image=imagenEx)
                ventana1.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n + 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

    if(tecla == "'j'"):
        if(n < 1040):
            canvas1.delete(imagenC2)
            n = n + 10
            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)
            if(p==1040):
                canvas1.delete(imagenC2)
                imagenEx1 = canvas1.create_image(1040,450, image = imagenEx)
                ventana1.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n - 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)
               
def NuevaVentana2():
    """
    """
    global imagenC1,imagenC2,p,q,canvas2,imagenCarro1,imagenCarro2, imagenCarro7, tecla,ventana2,imagenA,imagenCarro5,imagenC7,imagenC8
    global imagenC,imagenD,imagenB,yA,yB,limite,retroceso,m,n,r,s,imagenCarro3,imagenC3,imagenC4,Fuel1,Fuel2
    global s,s2, r,w,e, e1,k, k1, k2, k3, k4, k5, k6, m1, q1, puntos,puntos2, imagenEx,imagenEx1,imagenEx2,imagenEx3,imagenEx4,imagenCarro4,imagenC5,imagenC6
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas
    
    ventana2=Toplevel(ventana)
    ventana.iconify()
    ventana2.geometry("1400x520+0+0")
    ventana2.config(bg="white")
    ventana2.title("Road Fighter")
    canvas2 = Canvas(ventana2, width = 1400, height = 550)

    # Se va a crear una imagen
    k = 0 # posicion de carro 1
    k1 = 0 #posición de carro 2
    k2 = 0 #posicion de carro 3
    k3 = 0 # posicion de manchas de aceite
    k4 = 0 # posicion de manchas de aceite
    k5 = 0 # posicion de tanques de gasolina
    k6 = 0 # posicion de tanques de gasolina
    p = 250 #x carro1
    q = 450 #y carro1
    
    q1 = 600 
    n = 900 #y carro2
    m1 = 600 #x carro1
    m = 450 #x carro1

    xm1 = random.randint (230, 380)
    ym1 = 0

    xm2 = random.randint(880,1040) 
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    s = random.randint(230,380)
    r = 0
    w = random.randint(880,1040)
    e = 0
    e1 = 290
    yA = 260
    yB = -260
    limite = 785
    retroceso = -1040
    puntos = 0
    puntos2 = 0
    Fuel1 = 10000
    Fuel2 = 10000
    imagenpista = PhotoImage(file="pista1.png")
    imagenA = canvas2.create_image(350,265, image = imagenpista)
    imagenB = canvas2.create_image(350,-260,image = imagenpista)
    imagenC = canvas2.create_image(1000,265, image = imagenpista)
    imagenD = canvas2.create_image(1000,-260,image = imagenpista)
    name = Label(ventana2, text = "Jugador 1:" + entrada1.get(), font = "Arial").place(x = 530, y = 100)
    name1 = Label(ventana2, text = "Jugador 2:" + entrada2.get(),font = "Arial").place(x = 1175, y = 100)
    imagenCarro1 = PhotoImage(file="Carro1.png")
    imagenC1 = canvas2.create_image(p,q, image = imagenCarro1)
    imagenCarro2 = PhotoImage(file="Carro2.png")
    imagenC2 = canvas2.create_image(n,m, image = imagenCarro2)
    
    imagenCarro3 = PhotoImage(file="Carro3.png")
    imagenC3 = canvas2.create_image(s,r, image = imagenCarro3)
    imagenC4 = canvas2.create_image(w,e, image = imagenCarro3)
    
    imagenCarro4 = PhotoImage(file="Carro4.png")
    imagenC5 = canvas2.create_image(s,r, image = imagenCarro4)
    imagenC6 = canvas2.create_image(w,e, image = imagenCarro4)
    
    imagenCarro5 = PhotoImage(file="Carro5.png")
    imagenC7 = canvas2.create_image(p,e1, image = imagenCarro5)
    imagenC8 = canvas2.create_image(n,e1, image = imagenCarro5)
    
    imagenMancha = PhotoImage(file="mancha.png")
    imagenM1 = canvas2.create_image(xm1, ym1, image = imagenMancha)
    imagenM2 = canvas2.create_image(xm2, ym2, image = imagenMancha)

    imagenGas = PhotoImage (file="gasolina.png")
    imagenG1 = canvas2.create_image(xg1, yg1, image = imagenGas)
    imagenG2 = canvas2.create_image(xg2, yg2, image = imagenGas)
    
    imagenEx = PhotoImage(file="boom.png")
    ventana2.bind("<Key>", key2)
    mover2()
    moverCarros2()
    canvas2.pack()
    
    ventana2.mainloop()

def mover2():
    global ventana2,canvas2,imagenA,imagenB,imagenC,imagenD,yA,yB,limite,retroceso, puntos,puntos2, Fuel1,Fuel2
   
    if(yA>=limite):
        canvas2.move(imagenA,0,retroceso)
        canvas2.move(imagenC,0,retroceso)
        yA+=retroceso
        
    if(yB>=limite):
        canvas2.move(imagenB,0,retroceso)
        canvas2.move(imagenD,0,retroceso)
        yB+=retroceso
    yA+=2
    yB+=2
    puntos += 1
    puntos2 += 1
    puntoJ1 = Label(ventana2, text = "Puntos:" + str(puntos), font = "Arial").place(x = 530, y = 140)
    puntoJ2 = Label(ventana2, text = "Puntos:" + str(puntos2), font = "Arial").place(x = 1175, y = 140)
    FuelJ1 = Label(ventana2, text = "Fuel:" + str(Fuel1), font = "Arial").place(x = 530, y = 200)
    FuelJ2 = Label(ventana2, text = "Fuel:" + str(Fuel2), font = "Arial").place(x = 1175, y = 200)
    canvas2.move(imagenA,0,2) 
    canvas2.move(imagenB,0,2)
    canvas2.move(imagenC,0,2)
    canvas2.move(imagenD,0,2)
    ventana2.after(4, mover2)
    if (puntos == 15000):
        #imprimir en pantalla jugador1 gana
        #Cerrar ventana1
        #canvas1.after(500,timee)
        NuevaVentana2()
    if (puntos2 == 15000):
        #imprimir jugador2 gana
        #cerrar ventana1
        NuevaVentana2()

def moverCarros2():
    global p, q, n, m, y,ventana2,canvas2,imagenC3,imagenC4,imagenC7,imagenC8,yA,yB,limite,retroceso,w,e,s,r,k,k1,k2,s2,w2,s3,w3,imagenC5,imagenC6,x,Fuel1,Fuel2
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, k3, k4, k5, k6, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas, puntos, puntos2

    
    s = random.randint(230,380) #x de carroC3
    w = random.randint(880,1040) #x de carroC4
    s2 = random.randint(230,380) #x de carroC5
    w2 = random.randint(880,1040) #x de carroC6
    s3 = random.randint(250,350) #x de carroC5
    w3 = random.randint(800,1040)

    xm1 = random.randint(230,380)
    ym1 = 0

    xm2 = random.randint(880,1040)
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    if(canvas2.coords(imagenC5)[1] == 890.0):
        canvas2.move(imagenC5,0,-100)
        
    # Enemigo 1
    if (k>400):
        k=0
        imagenC3 = canvas2.create_image(s,r, image = imagenCarro3)
        imagenC4 = canvas2.create_image(w,e, image = imagenCarro3)

    k = k + 2
    canvas2.move(imagenC3,0,4)
    canvas2.move(imagenC4,0,4)

    distxC3C1 = (canvas2.coords(imagenC3)[0] - canvas2.coords(imagenC1)[0])**2
    distyC3C1 = (canvas2.coords(imagenC3)[1] - canvas2.coords(imagenC1)[1])**2
    distEuclC3C1 = sqrt(distxC3C1+distyC3C1)
    
    #print("C3 ", canvas1.coords(imagenC3))
    #print("C1 ", canvas1.coords(imagenC1))
    #print("distx ",  distxC3C1, " disty ",  distyC3C1, "euclidiana ", sqrt(distxC3C1+distyC3C1))
    
    if(distEuclC3C1 <= 55):
        Fuel1 -= 10
       # print("colision ")

    ################ colision 2 ################
    ############################################

    distxC5C1 = (canvas2.coords(imagenC5)[0] - canvas2.coords(imagenC1)[0])**2
    distyC5C1 = (canvas2.coords(imagenC5)[1] - canvas2.coords(imagenC1)[1])**2
    distEuclC5C1 = sqrt(distxC5C1+distyC5C1)
    if (distEuclC5C1 <= 60):
        Fuel1 -= 10
        canvas2.coords(imagenC1)[0] = canvas2.coords(imagenC1)[0] - 10
        
       # print("C5 ", canvas1.coords(imagenC5))
      #  print("C1 ", canvas1.coords(imagenC1))
     #   print("distx ",  distxC5C1, " disty ",  distyC5C1, "euclidiana ", sqrt(distxC5C1+distyC5C1))
    #    print("colision 2")
     #ventana1.after(60, moverCarros)


    # Enemigo 2
    if (k1>565):
        k1=0
        imagenC5 = canvas2.create_image(s2,r, image = imagenCarro4)
        imagenC6 = canvas2.create_image(w2,e, image = imagenCarro4)

    k1 = k1 + 2
    #print(canvas1.coords(imagenC5)[0])
    if(canvas2.coords(imagenC5)[0]== 390.0):
        x=1
    if(canvas2.coords(imagenC5)[0]== 225.0):
        x=0
    if(canvas2.coords(imagenC6)[0]== 1040.0):
        y=1
    if(canvas2.coords(imagenC6)[0]== 873.0):
        y=0
    if(y==0):
        canvas2.move(imagenC6,1,2)
    else:
        canvas2.move(imagenC6,-1,2)        
    if(x==0):
        canvas2.move(imagenC5,1,2)
    else:
        canvas2.move(imagenC5,-1,2)
        canvas2.coords(imagenC6)
    ventana2.after(60, moverCarros2)

    # Enemigo 3

    if(k2>580):
        k2 = 0
        imagenC7 = canvas2.create_image(s3,r, image = imagenCarro5)
        imagenC8 = canvas2.create_image(w3,e, image = imagenCarro5)
    k2 = k2 + 2
        
    canvas2.move(imagenC7,0,2)
    canvas2.move(imagenC8,0,2)
    #print(canvas1.coords(imagenC7)[1])
#    if(canvas1.coords(imagenC7)[1] > 620.0):
        #print("coso")
 #       canvas1.move(imagenC7,0,2)
        
    #if(canvas1.coords(imagenC7)[1]==canvas1.coords(imagenC1)[1]):
      #  canvas1.move(imagenC7,0,canvas1.coords(imagenC7)[1])



    #manchas de aceite quitan puntos y gasolina 
    if (k3 > 500):
        k3 = 0
        imagenM1 = canvas2.create_image(xm1, ym1, image = imagenMancha)

    k3 = k3 + 2
    canvas2.move (imagenM1, 0, 3)

    #colision con aceite player 1
    ##########################
    distxM1C1 = (canvas2.coords(imagenM1)[0] - canvas2.coords(imagenC1)[0])**2
    distyM1C1 = (canvas2.coords(imagenM1)[1] - canvas2.coords(imagenC1)[1])**2
    distEuclM1C1 = sqrt(distxM1C1+distyM1C1)
    if (distEuclM1C1 <= 60):
        Fuel1 -= 100
        puntos -= 10
        canvas2.move(imagenC1, 1, 1)
        p = p + 1
        
        
    if(k4 > 500):
        k4 = 0
        imagenM2 = canvas2.create_image(xm2, ym2, image = imagenMancha)
    k4 = k4 + 2
    canvas2.move (imagenM2,0,3)

    #colision con aceite player 2
    #############################
    distxM2C2 = (canvas2.coords(imagenM2)[0] - canvas2.coords(imagenC2)[0])**2
    distyM2C2 = (canvas2.coords(imagenM2)[1] - canvas2.coords(imagenC2)[1])**2
    distEuclM2C2 = sqrt(distxM2C2+distyM2C2)
    if (distEuclM2C2 <= 60):
        Fuel2 -= 100
        puntos2 -= 10
        canvas2.move(imagenC2, 1, 1)
        n = n + 1

    #gasolina
    if (k5 > 400):
        k5 = 0
        imagenG1 = canvas2.create_image(xg1, yg1, image = imagenGas)
    k5 = k5 + 2
    canvas2.move (imagenG1, 0, 3)

    #colision con gasolina player 1
    ##########################
    distxG1C1 = (canvas2.coords(imagenG1)[0] - canvas2.coords(imagenC1)[0])**2
    distyG1C1 = (canvas2.coords(imagenG1)[1] - canvas2.coords(imagenC1)[1])**2
    distEuclG1C1 = sqrt(distxG1C1+distyG1C1)
    if (distEuclG1C1 <= 60):
        Fuel1 += 250
        k5 = 400
        canvas2.delete(imagenG1)
    
    if (k6 > 400):
        k6 = 0
        imagenG2 = canvas2.create_image(xg2, yg2, image = imagenGas)
    k6 = k6 + 2
    canvas2.move(imagenG2, 0, 3)

    if (Fuel1 == 0):
        #imagen gameover gana jugador 2
        print ("jugador2")

    if (Fuel2 == 0):
        #imagen gameover gana jugador 1
        print("jugador1")

def key2(event):
    """
    """
    global e1,imagenC1,imagenC2,imagenC3,imagenC7,imagenCarro5,p,q,m,n,canvas2,imagenCarro1,tecla,ventana2,imagenCarro2,imagenEx,limite,w,q1,imagenC7,Fuel1,Fuel2
    tecla = repr(event.char)

    if(tecla == "'w'"):
        Fuel1 -= 10
        if(q < 500): 
            canvas2.delete(imagenC1)
            q = q - 10
            imagenC1 = canvas2.create_image(p,q,image=imagenCarro1)

    if(tecla == "'s'"):
        Fuel1 -= 10
        if(q > 0): 
            canvas2.delete(imagenC1)
            q = q + 10
            imagenC1 = canvas2.create_image(p,q,image=imagenCarro1)

    if(tecla == "'d'"):
        Fuel1 -= 10
        canvas2.move(imagenC7,5,0)
        if(p < 380):
            canvas2.delete(imagenC1)
            #canvas1.delete(imagenC7)
            p = p + 10
            imagenC1 = canvas2.create_image(p,q,image=imagenCarro1)
            #imagenC7 = canvas1.create_image(p,e1,image=imagenCarro5)
            if (p == 380):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(380,q,image=imagenEx)
##                ventana1.after(200,timee)             
##        else:
##            canvas1.delete(imagenC1)
##            p = p - 10
##            imagenC1 = canvas1.create_image(p,q, image=imagenCarro1)
##            

    if(tecla == "'a'"):
        Fuel1 -= 10
        canvas2.move(imagenC7,-5,0)
        if(p > 230):
            canvas2.delete(imagenC1)
            p = p - 10
            imagenC1 = canvas2.create_image(p,q,image=imagenCarro1)
            if ( p == 230):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(230,q,image=imagenEx)
##                ventana1.after(1,timee)
##                canvas1.delete(imagenEx)
                
##        else:
##            canvas1.delete(imagenC1)
##            p = p + 10
##            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)

    if(tecla == "'y'"):
        Fuel2 -= 10
        if(m < 500):
            canvas2.delete(imagenC2)
            m = m - 10
            imagenC2 = canvas2.create_image(n,m,image=imagenCarro2)

    if(tecla == "'h'"):
        Fuel2 -= 10
        if(m > 0):
            canvas2.delete(imagenC2)
            m = m + 10
            imagenC2 = canvas2.create_image(n,m,image=imagenCarro2)

    if(tecla == "'g'"):
        if(n > 880):
            canvas2.delete(imagenC2)
            n = n - 10
            imagenC2 = canvas2.create_image(n,m,image=imagenCarro2)
            if(p==880):
                canvas2.delete(imagenC2)
                imagenEx1 = canvas2.create_image(880,q,image=imagenEx)
                ventana2.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n + 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

    if(tecla == "'j'"):
        if(n < 1040):
            canvas2.delete(imagenC2)
            n = n + 10
            imagenC2 = canvas2.create_image(n,m,image=imagenCarro2)
            if(p==1040):
                canvas2.delete(imagenC2)
                imagenEx1 = canvas2.create_image(1040,450, image = imagenEx)
                ventana2.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n - 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

def NuevaVentana3():
    """
    """
    global imagenC1,imagenC2,p,q,canvas3,imagenCarro1,imagenCarro2, imagenCarro7, tecla,ventana3,imagenA,imagenCarro5,imagenC7,imagenC8
    global imagenC,imagenD,imagenB,yA,yB,limite,retroceso,m,n,r,s,imagenCarro3,imagenC3,imagenC4,Fuel1,Fuel2
    global s,s2, r,w,e, e1,k, k1, k2, k3, k4, k5, k6, m1, q1, puntos,puntos2, imagenEx,imagenEx1,imagenEx2,imagenEx3,imagenEx4,imagenCarro4,imagenC5,imagenC6
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas
    
    ventana3=Toplevel(ventana)
    ventana.iconify()
    ventana3.geometry("1400x520+0+0")
    ventana3.config(bg="white")
    ventana3.title("Road Fighter")
    canvas3 = Canvas(ventana3, width = 1400, height = 550)

    # Se va a crear una imagen
    k = 0 # posicion de carro 1
    k1 = 0 #posición de carro 2
    k2 = 0 #posicion de carro 3
    k3 = 0 # posicion de manchas de aceite
    k4 = 0 # posicion de manchas de aceite
    k5 = 0 # posicion de tanques de gasolina
    k6 = 0 # posicion de tanques de gasolina
    p = 250 #x carro1
    q = 450 #y carro1
    
    q1 = 600 
    n = 900 #y carro2
    m1 = 600 #x carro1
    m = 450 #x carro1

    xm1 = random.randint (230, 380)
    ym1 = 0

    xm2 = random.randint(880,1040) 
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    s = random.randint(230,380)
    r = 0
    w = random.randint(880,1040)
    e = 0
    e1 = 290
    yA = 260
    yB = -260
    limite = 785
    retroceso = -1040
    puntos = 0
    puntos2 = 0
    Fuel1 = 10000
    Fuel2 = 10000
    imagenpista = PhotoImage(file="pista1.png")
    imagenA = canvas3.create_image(350,265, image = imagenpista)
    imagenB = canvas3.create_image(350,-260,image = imagenpista)
    imagenC = canvas3.create_image(1000,265, image = imagenpista)
    imagenD = canvas3.create_image(1000,-260,image = imagenpista)
    name = Label(ventana3, text = "Jugador 1:" + entrada1.get(), font = "Arial").place(x = 530, y = 100)
    name1 = Label(ventana3, text = "Jugador 2:" + entrada2.get(),font = "Arial").place(x = 1175, y = 100)
    imagenCarro1 = PhotoImage(file="Carro1.png")
    imagenC1 = canvas3.create_image(p,q, image = imagenCarro1)
    imagenCarro2 = PhotoImage(file="Carro2.png")
    imagenC2 = canvas3.create_image(n,m, image = imagenCarro2)
    
    imagenCarro3 = PhotoImage(file="Carro3.png")
    imagenC3 = canvas3.create_image(s,r, image = imagenCarro3)
    imagenC4 = canvas3.create_image(w,e, image = imagenCarro3)
    
    imagenCarro4 = PhotoImage(file="Carro4.png")
    imagenC5 = canvas3.create_image(s,r, image = imagenCarro4)
    imagenC6 = canvas3.create_image(w,e, image = imagenCarro4)
    
    imagenCarro5 = PhotoImage(file="Carro5.png")
    imagenC7 = canvas3.create_image(p,e1, image = imagenCarro5)
    imagenC8 = canvas3.create_image(n,e1, image = imagenCarro5)
    
    imagenMancha = PhotoImage(file="mancha.png")
    imagenM1 = canvas3.create_image(xm1, ym1, image = imagenMancha)
    imagenM2 = canvas3.create_image(xm2, ym2, image = imagenMancha)

    imagenGas = PhotoImage (file="gasolina.png")
    imagenG1 = canvas3.create_image(xg1, yg1, image = imagenGas)
    imagenG2 = canvas3.create_image(xg2, yg2, image = imagenGas)
    
    imagenEx = PhotoImage(file="boom.png")
    ventana3.bind("<Key>", key3)
    mover3()
    moverCarros3()
    canvas3.pack()
    
    ventana3.mainloop()

def mover3():
    global ventana3,canvas3,imagenA,imagenB,imagenC,imagenD,yA,yB,limite,retroceso, puntos,puntos2, Fuel1,Fuel2
   
    if(yA>=limite):
        canvas3.move(imagenA,0,retroceso)
        canvas3.move(imagenC,0,retroceso)
        yA+=retroceso
        
    if(yB>=limite):
        canvas3.move(imagenB,0,retroceso)
        canvas3.move(imagenD,0,retroceso)
        yB+=retroceso
    yA+=2
    yB+=2
    puntos += 1
    puntos2 += 1
    puntoJ1 = Label(ventana3, text = "Puntos:" + str(puntos), font = "Arial").place(x = 530, y = 140)
    puntoJ2 = Label(ventana3, text = "Puntos:" + str(puntos2), font = "Arial").place(x = 1175, y = 140)
    FuelJ1 = Label(ventana3, text = "Fuel:" + str(Fuel1), font = "Arial").place(x = 530, y = 200)
    FuelJ2 = Label(ventana3, text = "Fuel:" + str(Fuel2), font = "Arial").place(x = 1175, y = 200)
    canvas3.move(imagenA,0,2) 
    canvas3.move(imagenB,0,2)
    canvas3.move(imagenC,0,2)
    canvas3.move(imagenD,0,2)
    ventana3.after(4, mover3)
    if (puntos == 15000):
        #imprimir en pantalla jugador1 gana
        #Cerrar ventana1
        #canvas1.after(500,timee)
        NuevaVentana2()
    if (puntos2 == 15000):
        #imprimir jugador2 gana
        #cerrar ventana1
        NuevaVentana2()

def moverCarros3():
    global p, q, n, m, y,ventana3,canvas3,imagenC3,imagenC4,imagenC7,imagenC8,yA,yB,limite,retroceso,w,e,s,r,k,k1,k2,s2,w2,s3,w3,imagenC5,imagenC6,x,Fuel1,Fuel2
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, k3, k4, k5, k6, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas, puntos, puntos2

    
    s = random.randint(230,380) #x de carroC3
    w = random.randint(880,1040) #x de carroC4
    s2 = random.randint(230,380) #x de carroC5
    w2 = random.randint(880,1040) #x de carroC6
    s3 = random.randint(250,350) #x de carroC5
    w3 = random.randint(800,1040)

    xm1 = random.randint(230,380)
    ym1 = 0

    xm2 = random.randint(880,1040)
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    if(canvas3.coords(imagenC5)[1] == 890.0):
        canvas3.move(imagenC5,0,-100)
        
    # Enemigo 1
    if (k>400):
        k=0
        imagenC3 = canvas3.create_image(s,r, image = imagenCarro3)
        imagenC4 = canvas3.create_image(w,e, image = imagenCarro3)

    k = k + 2
    canvas3.move(imagenC3,0,4)
    canvas3.move(imagenC4,0,4)

    distxC3C1 = (canvas3.coords(imagenC3)[0] - canvas3.coords(imagenC1)[0])**2
    distyC3C1 = (canvas3.coords(imagenC3)[1] - canvas3.coords(imagenC1)[1])**2
    distEuclC3C1 = sqrt(distxC3C1+distyC3C1)
    
    #print("C3 ", canvas1.coords(imagenC3))
    #print("C1 ", canvas1.coords(imagenC1))
    #print("distx ",  distxC3C1, " disty ",  distyC3C1, "euclidiana ", sqrt(distxC3C1+distyC3C1))
    
    if(distEuclC3C1 <= 55):
        Fuel1 -= 10
       # print("colision ")

    ################ colision 2 ################
    ############################################

    distxC5C1 = (canvas3.coords(imagenC5)[0] - canvas3.coords(imagenC1)[0])**2
    distyC5C1 = (canvas3.coords(imagenC5)[1] - canvas3.coords(imagenC1)[1])**2
    distEuclC5C1 = sqrt(distxC5C1+distyC5C1)
    if (distEuclC5C1 <= 60):
        Fuel1 -= 10
        canvas3.coords(imagenC1)[0] = canvas3.coords(imagenC1)[0] - 10
        
       # print("C5 ", canvas1.coords(imagenC5))
      #  print("C1 ", canvas1.coords(imagenC1))
     #   print("distx ",  distxC5C1, " disty ",  distyC5C1, "euclidiana ", sqrt(distxC5C1+distyC5C1))
    #    print("colision 2")
     #ventana1.after(60, moverCarros)


    # Enemigo 2
    if (k1>565):
        k1=0
        imagenC5 = canvas3.create_image(s2,r, image = imagenCarro4)
        imagenC6 = canvas3.create_image(w2,e, image = imagenCarro4)

    k1 = k1 + 2
    #print(canvas1.coords(imagenC5)[0])
    if(canvas3.coords(imagenC5)[0]== 390.0):
        x=1
    if(canvas3.coords(imagenC5)[0]== 225.0):
        x=0
    if(canvas3.coords(imagenC6)[0]== 1040.0):
        y=1
    if(canvas3.coords(imagenC6)[0]== 873.0):
        y=0
    if(y==0):
        canvas3.move(imagenC6,1,2)
    else:
        canvas3.move(imagenC6,-1,2)        
    if(x==0):
        canvas3.move(imagenC5,1,2)
    else:
        canvas3.move(imagenC5,-1,2)
        canvas3.coords(imagenC6)
    ventana3.after(60, moverCarros3)

    # Enemigo 3

    if(k2>580):
        k2 = 0
        imagenC7 = canvas3.create_image(s3,r, image = imagenCarro5)
        imagenC8 = canvas3.create_image(w3,e, image = imagenCarro5)
    k2 = k2 + 2
        
    canvas3.move(imagenC7,0,2)
    canvas3.move(imagenC8,0,2)
    #print(canvas1.coords(imagenC7)[1])
#    if(canvas1.coords(imagenC7)[1] > 620.0):
        #print("coso")
 #       canvas1.move(imagenC7,0,2)
        
    #if(canvas1.coords(imagenC7)[1]==canvas1.coords(imagenC1)[1]):
      #  canvas1.move(imagenC7,0,canvas1.coords(imagenC7)[1])



    #manchas de aceite quitan puntos y gasolina 
    if (k3 > 500):
        k3 = 0
        imagenM1 = canvas3.create_image(xm1, ym1, image = imagenMancha)

    k3 = k3 + 2
    canvas3.move (imagenM1, 0, 3)

    #colision con aceite player 1
    ##########################
    distxM1C1 = (canvas3.coords(imagenM1)[0] - canvas3.coords(imagenC1)[0])**2
    distyM1C1 = (canvas3.coords(imagenM1)[1] - canvas3.coords(imagenC1)[1])**2
    distEuclM1C1 = sqrt(distxM1C1+distyM1C1)
    if (distEuclM1C1 <= 60):
        Fuel1 -= 100
        puntos -= 10
        canvas3.move(imagenC1, 1, 1)
        p = p + 1
        
        
    if(k4 > 500):
        k4 = 0
        imagenM2 = canvas3.create_image(xm2, ym2, image = imagenMancha)
    k4 = k4 + 2
    canvas3.move (imagenM2,0,3)

    #colision con aceite player 2
    #############################
    distxM2C2 = (canvas3.coords(imagenM2)[0] - canvas3.coords(imagenC2)[0])**2
    distyM2C2 = (canvas3.coords(imagenM2)[1] - canvas3.coords(imagenC2)[1])**2
    distEuclM2C2 = sqrt(distxM2C2+distyM2C2)
    if (distEuclM2C2 <= 60):
        Fuel2 -= 100
        puntos2 -= 10
        canvas3.move(imagenC2, 1, 1)
        n = n + 1

    #gasolina
    if (k5 > 400):
        k5 = 0
        imagenG1 = canvas3.create_image(xg1, yg1, image = imagenGas)
    k5 = k5 + 2
    canvas3.move (imagenG1, 0, 3)

    #colision con gasolina player 1
    ##########################
    distxG1C1 = (canvas3.coords(imagenG1)[0] - canvas3.coords(imagenC1)[0])**2
    distyG1C1 = (canvas3.coords(imagenG1)[1] - canvas3.coords(imagenC1)[1])**2
    distEuclG1C1 = sqrt(distxG1C1+distyG1C1)
    if (distEuclG1C1 <= 60):
        Fuel1 += 250
        k5 = 400
        canvas3.delete(imagenG1)
    
    if (k6 > 400):
        k6 = 0
        imagenG2 = canvas3.create_image(xg2, yg2, image = imagenGas)
    k6 = k6 + 2
    canvas3.move(imagenG2, 0, 3)

    if (Fuel1 == 0):
        #imagen gameover gana jugador 2
        print ("jugador2")

    if (Fuel2 == 0):
        #imagen gameover gana jugador 1
        print("jugador1")
        
def key3(event):
    """
    """
    global e1,imagenC1,imagenC2,imagenC3,imagenC7,imagenCarro5,p,q,m,n,canvas3,imagenCarro1,tecla,ventana3,imagenCarro2,imagenEx,limite,w,q1,imagenC7,Fuel1,Fuel2
    tecla = repr(event.char)

    if(tecla == "'w'"):
        Fuel1 -= 10
        if(q < 500): 
            canvas3.delete(imagenC1)
            q = q - 10
            imagenC1 = canvas3.create_image(p,q,image=imagenCarro1)

    if(tecla == "'s'"):
        Fuel1 -= 10
        if(q > 0): 
            canvas3.delete(imagenC1)
            q = q + 10
            imagenC1 = canvas3.create_image(p,q,image=imagenCarro1)

    if(tecla == "'d'"):
        Fuel1 -= 10
        canvas3.move(imagenC7,5,0)
        if(p < 380):
            canvas3.delete(imagenC1)
            #canvas1.delete(imagenC7)
            p = p + 10
            imagenC1 = canvas3.create_image(p,q,image=imagenCarro1)
            #imagenC7 = canvas1.create_image(p,e1,image=imagenCarro5)
            if (p == 380):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(380,q,image=imagenEx)
##                ventana1.after(200,timee)             
##        else:
##            canvas1.delete(imagenC1)
##            p = p - 10
##            imagenC1 = canvas1.create_image(p,q, image=imagenCarro1)
##            

    if(tecla == "'a'"):
        Fuel1 -= 10
        canvas3.move(imagenC7,-5,0)
        if(p > 230):
            canvas3.delete(imagenC1)
            p = p - 10
            imagenC1 = canvas3.create_image(p,q,image=imagenCarro1)
            if ( p == 230):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(230,q,image=imagenEx)
##                ventana1.after(1,timee)
##                canvas1.delete(imagenEx)
                
##        else:
##            canvas1.delete(imagenC1)
##            p = p + 10
##            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)

    if(tecla == "'y'"):
        Fuel2 -= 10
        if(m < 500):
            canvas3.delete(imagenC2)
            m = m - 10
            imagenC2 = canvas3.create_image(n,m,image=imagenCarro2)

    if(tecla == "'h'"):
        Fuel2 -= 10
        if(m > 0):
            canvas3.delete(imagenC2)
            m = m + 10
            imagenC2 = canvas3.create_image(n,m,image=imagenCarro2)

    if(tecla == "'g'"):
        if(n > 880):
            canvas3.delete(imagenC2)
            n = n - 10
            imagenC2 = canvas3.create_image(n,m,image=imagenCarro2)
            if(p==880):
                canvas3.delete(imagenC2)
                imagenEx1 = canvas3.create_image(880,q,image=imagenEx)
                ventana3.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n + 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

    if(tecla == "'j'"):
        if(n < 1040):
            canvas3.delete(imagenC2)
            n = n + 10
            imagenC2 = canvas3.create_image(n,m,image=imagenCarro2)
            if(p==1040):
                canvas3.delete(imagenC2)
                imagenEx1 = canvas3.create_image(1040,450, image = imagenEx)
                ventana3.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n - 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

def NuevaVentana4():
    """
    """
    global imagenC1,imagenC2,p,q,canvas4,imagenCarro1,imagenCarro2, imagenCarro7, tecla,ventana4,imagenA,imagenCarro5,imagenC7,imagenC8
    global imagenC,imagenD,imagenB,yA,yB,limite,retroceso,m,n,r,s,imagenCarro3,imagenC3,imagenC4,Fuel1,Fuel2
    global s,s2, r,w,e, e1,k, k1, k2, k3, k4, k5, k6, m1, q1, puntos,puntos2, imagenEx,imagenEx1,imagenEx2,imagenEx3,imagenEx4,imagenCarro4,imagenC5,imagenC6
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas
    
    ventana4=Toplevel(ventana)
    ventana.iconify()
    ventana4.geometry("1400x520+0+0")
    ventana4.config(bg="white")
    ventana4.title("Road Fighter")
    canvas4 = Canvas(ventana4, width = 1400, height = 550)

    # Se va a crear una imagen
    k = 0 # posicion de carro 1
    k1 = 0 #posición de carro 2
    k2 = 0 #posicion de carro 3
    k3 = 0 # posicion de manchas de aceite
    k4 = 0 # posicion de manchas de aceite
    k5 = 0 # posicion de tanques de gasolina
    k6 = 0 # posicion de tanques de gasolina
    p = 250 #x carro1
    q = 450 #y carro1
    
    q1 = 600 
    n = 900 #y carro2
    m1 = 600 #x carro1
    m = 450 #x carro1

    xm1 = random.randint (230, 380)
    ym1 = 0

    xm2 = random.randint(880,1040) 
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    s = random.randint(230,380)
    r = 0
    w = random.randint(880,1040)
    e = 0
    e1 = 290
    yA = 260
    yB = -260
    limite = 785
    retroceso = -1040
    puntos = 0
    puntos2 = 0
    Fuel1 = 10000
    Fuel2 = 10000
    imagenpista = PhotoImage(file="pista1.png")
    imagenA = canvas4.create_image(350,265, image = imagenpista)
    imagenB = canvas4.create_image(350,-260,image = imagenpista)
    imagenC = canvas4.create_image(1000,265, image = imagenpista)
    imagenD = canvas4.create_image(1000,-260,image = imagenpista)
    name = Label(ventana4, text = "Jugador 1:" + entrada1.get(), font = "Arial").place(x = 530, y = 100)
    name1 = Label(ventana4, text = "Jugador 2:" + entrada2.get(),font = "Arial").place(x = 1175, y = 100)
    imagenCarro1 = PhotoImage(file="Carro1.png")
    imagenC1 = canvas4.create_image(p,q, image = imagenCarro1)
    imagenCarro2 = PhotoImage(file="Carro2.png")
    imagenC2 = canvas4.create_image(n,m, image = imagenCarro2)
    
    imagenCarro3 = PhotoImage(file="Carro3.png")
    imagenC3 = canvas4.create_image(s,r, image = imagenCarro3)
    imagenC4 = canvas4.create_image(w,e, image = imagenCarro3)
    
    imagenCarro4 = PhotoImage(file="Carro4.png")
    imagenC5 = canvas4.create_image(s,r, image = imagenCarro4)
    imagenC6 = canvas4.create_image(w,e, image = imagenCarro4)
    
    imagenCarro5 = PhotoImage(file="Carro5.png")
    imagenC7 = canvas4.create_image(p,e1, image = imagenCarro5)
    imagenC8 = canvas4.create_image(n,e1, image = imagenCarro5)
    
    imagenMancha = PhotoImage(file="mancha.png")
    imagenM1 = canvas4.create_image(xm1, ym1, image = imagenMancha)
    imagenM2 = canvas4.create_image(xm2, ym2, image = imagenMancha)

    imagenGas = PhotoImage (file="gasolina.png")
    imagenG1 = canvas4.create_image(xg1, yg1, image = imagenGas)
    imagenG2 = canvas4.create_image(xg2, yg2, image = imagenGas)
    
    imagenEx = PhotoImage(file="boom.png")
    ventana4.bind("<Key>", key4)
    mover4()
    moverCarros4()
    canvas4.pack()
    
    ventana4.mainloop()

def mover4():
    global ventana4,canvas4,imagenA,imagenB,imagenC,imagenD,yA,yB,limite,retroceso, puntos,puntos2, Fuel1,Fuel2
   
    if(yA>=limite):
        canvas4.move(imagenA,0,retroceso)
        canvas4.move(imagenC,0,retroceso)
        yA+=retroceso
        
    if(yB>=limite):
        canvas4.move(imagenB,0,retroceso)
        canvas4.move(imagenD,0,retroceso)
        yB+=retroceso
    yA+=2
    yB+=2
    puntos += 1
    puntos2 += 1
    puntoJ1 = Label(ventana4, text = "Puntos:" + str(puntos), font = "Arial").place(x = 530, y = 140)
    puntoJ2 = Label(ventana4, text = "Puntos:" + str(puntos2), font = "Arial").place(x = 1175, y = 140)
    FuelJ1 = Label(ventana4, text = "Fuel:" + str(Fuel1), font = "Arial").place(x = 530, y = 200)
    FuelJ2 = Label(ventana4, text = "Fuel:" + str(Fuel2), font = "Arial").place(x = 1175, y = 200)
    canvas4.move(imagenA,0,2) 
    canvas4.move(imagenB,0,2)
    canvas4.move(imagenC,0,2)
    canvas4.move(imagenD,0,2)
    ventana4.after(4, mover4)
    if (puntos == 15000):
        #imprimir en pantalla jugador1 gana
        #Cerrar ventana1
        #canvas1.after(500,timee)
        NuevaVentana2()
    if (puntos2 == 15000):
        #imprimir jugador2 gana
        #cerrar ventana1
        NuevaVentana2()

def moverCarros4():
    global p, q, n, m, y,ventana4,canvas4,imagenC3,imagenC4,imagenC7,imagenC8,yA,yB,limite,retroceso,w,e,s,r,k,k1,k2,s2,w2,s3,w3,imagenC5,imagenC6,x,Fuel1,Fuel2
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, k3, k4, k5, k6, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas, puntos, puntos2

    
    s = random.randint(230,380) #x de carroC3
    w = random.randint(880,1040) #x de carroC4
    s2 = random.randint(230,380) #x de carroC5
    w2 = random.randint(880,1040) #x de carroC6
    s3 = random.randint(250,350) #x de carroC5
    w3 = random.randint(800,1040)

    xm1 = random.randint(230,380)
    ym1 = 0

    xm2 = random.randint(880,1040)
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    if(canvas4.coords(imagenC5)[1] == 890.0):
        canvas4.move(imagenC5,0,-100)
        
    # Enemigo 1
    if (k>400):
        k=0
        imagenC3 = canvas4.create_image(s,r, image = imagenCarro3)
        imagenC4 = canvas4.create_image(w,e, image = imagenCarro3)

    k = k + 2
    canvas4.move(imagenC3,0,4)
    canvas4.move(imagenC4,0,4)

    distxC3C1 = (canvas4.coords(imagenC3)[0] - canvas4.coords(imagenC1)[0])**2
    distyC3C1 = (canvas4.coords(imagenC3)[1] - canvas4.coords(imagenC1)[1])**2
    distEuclC3C1 = sqrt(distxC3C1+distyC3C1)
    
    #print("C3 ", canvas1.coords(imagenC3))
    #print("C1 ", canvas1.coords(imagenC1))
    #print("distx ",  distxC3C1, " disty ",  distyC3C1, "euclidiana ", sqrt(distxC3C1+distyC3C1))
    
    if(distEuclC3C1 <= 55):
        Fuel1 -= 10
       # print("colision ")

    ################ colision 2 ################
    ############################################

    distxC5C1 = (canvas4.coords(imagenC5)[0] - canvas4.coords(imagenC1)[0])**2
    distyC5C1 = (canvas4.coords(imagenC5)[1] - canvas4.coords(imagenC1)[1])**2
    distEuclC5C1 = sqrt(distxC5C1+distyC5C1)
    if (distEuclC5C1 <= 60):
        Fuel1 -= 10
        canvas4.coords(imagenC1)[0] = canvas4.coords(imagenC1)[0] - 10
        
       # print("C5 ", canvas1.coords(imagenC5))
      #  print("C1 ", canvas1.coords(imagenC1))
     #   print("distx ",  distxC5C1, " disty ",  distyC5C1, "euclidiana ", sqrt(distxC5C1+distyC5C1))
    #    print("colision 2")
     #ventana1.after(60, moverCarros)


    # Enemigo 2
    if (k1>565):
        k1=0
        imagenC5 = canvas4.create_image(s2,r, image = imagenCarro4)
        imagenC6 = canvas4.create_image(w2,e, image = imagenCarro4)

    k1 = k1 + 2
    #print(canvas1.coords(imagenC5)[0])
    if(canvas4.coords(imagenC5)[0]== 390.0):
        x=1
    if(canvas4.coords(imagenC5)[0]== 225.0):
        x=0
    if(canvas4.coords(imagenC6)[0]== 1040.0):
        y=1
    if(canvas4.coords(imagenC6)[0]== 873.0):
        y=0
    if(y==0):
        canvas4.move(imagenC6,1,2)
    else:
        canvas4.move(imagenC6,-1,2)        
    if(x==0):
        canvas4.move(imagenC5,1,2)
    else:
        canvas3.move(imagenC5,-1,2)
        canvas3.coords(imagenC6)
    ventana4.after(60, moverCarros4)

    # Enemigo 3

    if(k2>580):
        k2 = 0
        imagenC7 = canvas4.create_image(s3,r, image = imagenCarro5)
        imagenC8 = canvas4.create_image(w3,e, image = imagenCarro5)
    k2 = k2 + 2
        
    canvas4.move(imagenC7,0,2)
    canvas4.move(imagenC8,0,2)
    #print(canvas1.coords(imagenC7)[1])
#    if(canvas1.coords(imagenC7)[1] > 620.0):
        #print("coso")
 #       canvas1.move(imagenC7,0,2)
        
    #if(canvas1.coords(imagenC7)[1]==canvas1.coords(imagenC1)[1]):
      #  canvas1.move(imagenC7,0,canvas1.coords(imagenC7)[1])



    #manchas de aceite quitan puntos y gasolina 
    if (k3 > 500):
        k3 = 0
        imagenM1 = canvas4.create_image(xm1, ym1, image = imagenMancha)

    k3 = k3 + 2
    canvas4.move (imagenM1, 0, 3)

    #colision con aceite player 1
    ##########################
    distxM1C1 = (canvas4.coords(imagenM1)[0] - canvas4.coords(imagenC1)[0])**2
    distyM1C1 = (canvas4.coords(imagenM1)[1] - canvas4.coords(imagenC1)[1])**2
    distEuclM1C1 = sqrt(distxM1C1+distyM1C1)
    if (distEuclM1C1 <= 60):
        Fuel1 -= 100
        puntos -= 10
        canvas4.move(imagenC1, 1, 1)
        p = p + 1
        
        
    if(k4 > 500):
        k4 = 0
        imagenM2 = canvas4.create_image(xm2, ym2, image = imagenMancha)
    k4 = k4 + 2
    canvas4.move (imagenM2,0,3)

    #colision con aceite player 2
    #############################
    distxM2C2 = (canvas4.coords(imagenM2)[0] - canvas4.coords(imagenC2)[0])**2
    distyM2C2 = (canvas4.coords(imagenM2)[1] - canvas4.coords(imagenC2)[1])**2
    distEuclM2C2 = sqrt(distxM2C2+distyM2C2)
    if (distEuclM2C2 <= 60):
        Fuel2 -= 100
        puntos2 -= 10
        canvas4.move(imagenC2, 1, 1)
        n = n + 1

    #gasolina
    if (k5 > 400):
        k5 = 0
        imagenG1 = canvas4.create_image(xg1, yg1, image = imagenGas)
    k5 = k5 + 2
    canvas4.move (imagenG1, 0, 3)

    #colision con gasolina player 1
    ##########################
    distxG1C1 = (canvas4.coords(imagenG1)[0] - canvas4.coords(imagenC1)[0])**2
    distyG1C1 = (canvas4.coords(imagenG1)[1] - canvas4.coords(imagenC1)[1])**2
    distEuclG1C1 = sqrt(distxG1C1+distyG1C1)
    if (distEuclG1C1 <= 60):
        Fuel1 += 250
        k5 = 400
        canvas34.delete(imagenG1)
    
    if (k6 > 400):
        k6 = 0
        imagenG2 = canvas4.create_image(xg2, yg2, image = imagenGas)
    k6 = k6 + 2
    canvas4.move(imagenG2, 0, 3)

    if (Fuel1 == 0):
        #imagen gameover gana jugador 2
        print ("jugador2")

    if (Fuel2 == 0):
        #imagen gameover gana jugador 1
        print("jugador1")

def key4(event):
    """
    """
    global e1,imagenC1,imagenC2,imagenC3,imagenC7,imagenCarro5,p,q,m,n,canvas4,imagenCarro1,tecla,ventana4,imagenCarro2,imagenEx,limite,w,q1,imagenC7,Fuel1,Fuel2
    tecla = repr(event.char)

    if(tecla == "'w'"):
        Fuel1 -= 10
        if(q < 500): 
            canvas4.delete(imagenC1)
            q = q - 10
            imagenC1 = canvas4.create_image(p,q,image=imagenCarro1)

    if(tecla == "'s'"):
        Fuel1 -= 10
        if(q > 0): 
            canvas4.delete(imagenC1)
            q = q + 10
            imagenC1 = canvas4.create_image(p,q,image=imagenCarro1)

    if(tecla == "'d'"):
        Fuel1 -= 10
        canvas4.move(imagenC7,5,0)
        if(p < 380):
            canvas4.delete(imagenC1)
            #canvas1.delete(imagenC7)
            p = p + 10
            imagenC1 = canvas4.create_image(p,q,image=imagenCarro1)
            #imagenC7 = canvas1.create_image(p,e1,image=imagenCarro5)
            if (p == 380):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(380,q,image=imagenEx)
##                ventana1.after(200,timee)             
##        else:
##            canvas1.delete(imagenC1)
##            p = p - 10
##            imagenC1 = canvas1.create_image(p,q, image=imagenCarro1)
##            

    if(tecla == "'a'"):
        Fuel1 -= 10
        canvas4.move(imagenC7,-5,0)
        if(p > 230):
            canvas4.delete(imagenC1)
            p = p - 10
            imagenC1 = canvas4.create_image(p,q,image=imagenCarro1)
            if ( p == 230):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(230,q,image=imagenEx)
##                ventana1.after(1,timee)
##                canvas1.delete(imagenEx)
                
##        else:
##            canvas1.delete(imagenC1)
##            p = p + 10
##            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)

    if(tecla == "'y'"):
        Fuel2 -= 10
        if(m < 500):
            canvas4.delete(imagenC2)
            m = m - 10
            imagenC2 = canvas4.create_image(n,m,image=imagenCarro2)

    if(tecla == "'h'"):
        Fuel2 -= 10
        if(m > 0):
            canvas4.delete(imagenC2)
            m = m + 10
            imagenC2 = canvas4.create_image(n,m,image=imagenCarro2)

    if(tecla == "'g'"):
        if(n > 880):
            canvas4.delete(imagenC2)
            n = n - 10
            imagenC2 = canvas4.create_image(n,m,image=imagenCarro2)
            if(p==880):
                canvas4.delete(imagenC2)
                imagenEx1 = canvas4.create_image(880,q,image=imagenEx)
                ventana4.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n + 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

    if(tecla == "'j'"):
        if(n < 1040):
            canvas4.delete(imagenC2)
            n = n + 10
            imagenC2 = canvas4.create_image(n,m,image=imagenCarro2)
            if(p==1040):
                canvas1.delete(imagenC2)
                imagenEx1 = canvas4.create_image(1040,450, image = imagenEx)
                ventana4.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n - 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

def NuevaVentana5():
    """
    """
    global imagenC1,imagenC2,p,q,canvas5,imagenCarro1,imagenCarro2, imagenCarro7, tecla,ventana5,imagenA,imagenCarro5,imagenC7,imagenC8
    global imagenC,imagenD,imagenB,yA,yB,limite,retroceso,m,n,r,s,imagenCarro3,imagenC3,imagenC4,Fuel1,Fuel2
    global s,s2, r,w,e, e1,k, k1, k2, k3, k4, k5, k6, m1, q1, puntos,puntos2, imagenEx,imagenEx1,imagenEx2,imagenEx3,imagenEx4,imagenCarro4,imagenC5,imagenC6
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas
    
    ventana5=Toplevel(ventana)
    ventana.iconify()
    ventana5.geometry("1400x520+0+0")
    ventana5.config(bg="white")
    ventana5.title("Road Fighter")
    canvas5 = Canvas(ventana5, width = 1400, height = 550)

    # Se va a crear una imagen
    k = 0 # posicion de carro 1
    k1 = 0 #posición de carro 2
    k2 = 0 #posicion de carro 3
    k3 = 0 # posicion de manchas de aceite
    k4 = 0 # posicion de manchas de aceite
    k5 = 0 # posicion de tanques de gasolina
    k6 = 0 # posicion de tanques de gasolina
    p = 250 #x carro1
    q = 450 #y carro1
    
    q1 = 600 
    n = 900 #y carro2
    m1 = 600 #x carro1
    m = 450 #x carro1

    xm1 = random.randint (230, 380)
    ym1 = 0

    xm2 = random.randint(880,1040) 
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    s = random.randint(230,380)
    r = 0
    w = random.randint(880,1040)
    e = 0
    e1 = 290
    yA = 260
    yB = -260
    limite = 785
    retroceso = -1040
    puntos = 0
    puntos2 = 0
    Fuel1 = 10000
    Fuel2 = 10000
    imagenpista = PhotoImage(file="pista1.png")
    imagenA = canvas5.create_image(350,265, image = imagenpista)
    imagenB = canvas5.create_image(350,-260,image = imagenpista)
    imagenC = canvas5.create_image(1000,265, image = imagenpista)
    imagenD = canvas5.create_image(1000,-260,image = imagenpista)
    name = Label(ventana5, text = "Jugador 1:" + entrada1.get(), font = "Arial").place(x = 530, y = 100)
    name1 = Label(ventana5, text = "Jugador 2:" + entrada2.get(),font = "Arial").place(x = 1175, y = 100)
    imagenCarro1 = PhotoImage(file="Carro1.png")
    imagenC1 = canvas5.create_image(p,q, image = imagenCarro1)
    imagenCarro2 = PhotoImage(file="Carro2.png")
    imagenC2 = canvas5.create_image(n,m, image = imagenCarro2)
    
    imagenCarro3 = PhotoImage(file="Carro3.png")
    imagenC3 = canvas5.create_image(s,r, image = imagenCarro3)
    imagenC4 = canvas5.create_image(w,e, image = imagenCarro3)
    
    imagenCarro4 = PhotoImage(file="Carro4.png")
    imagenC5 = canvas5.create_image(s,r, image = imagenCarro4)
    imagenC6 = canvas5.create_image(w,e, image = imagenCarro4)
    
    imagenCarro5 = PhotoImage(file="Carro5.png")
    imagenC7 = canvas5.create_image(p,e1, image = imagenCarro5)
    imagenC8 = canvas5.create_image(n,e1, image = imagenCarro5)
    
    imagenMancha = PhotoImage(file="mancha.png")
    imagenM1 = canvas5.create_image(xm1, ym1, image = imagenMancha)
    imagenM2 = canvas5.create_image(xm2, ym2, image = imagenMancha)

    imagenGas = PhotoImage (file="gasolina.png")
    imagenG1 = canvas5.create_image(xg1, yg1, image = imagenGas)
    imagenG2 = canvas5.create_image(xg2, yg2, image = imagenGas)
    
    imagenEx = PhotoImage(file="boom.png")
    ventana5.bind("<Key>", key5)
    mover5()
    moverCarros5()
    canvas5.pack()
 
    ventana5.mainloop()

def mover5():
    global ventana5,canvas5,imagenA,imagenB,imagenC,imagenD,yA,yB,limite,retroceso, puntos,puntos2, Fuel1,Fuel2
   
    if(yA>=limite):
        canvas5.move(imagenA,0,retroceso)
        canvas5.move(imagenC,0,retroceso)
        yA+=retroceso
        
    if(yB>=limite):
        canvas5.move(imagenB,0,retroceso)
        canvas5.move(imagenD,0,retroceso)
        yB+=retroceso
    yA+=2
    yB+=2
    puntos += 1
    puntos2 += 1
    puntoJ1 = Label(ventana5, text = "Puntos:" + str(puntos), font = "Arial").place(x = 530, y = 140)
    puntoJ2 = Label(ventana5, text = "Puntos:" + str(puntos2), font = "Arial").place(x = 1175, y = 140)
    FuelJ1 = Label(ventana5, text = "Fuel:" + str(Fuel1), font = "Arial").place(x = 530, y = 200)
    FuelJ2 = Label(ventana5, text = "Fuel:" + str(Fuel2), font = "Arial").place(x = 1175, y = 200)
    canvas5.move(imagenA,0,2) 
    canvas5.move(imagenB,0,2)
    canvas5.move(imagenC,0,2)
    canvas5.move(imagenD,0,2)
    ventana5.after(4, mover5)
    if (puntos == 15000):
        #imprimir en pantalla jugador1 gana
        #Cerrar ventana1
        #canvas1.after(500,timee)
        NuevaVentana2()
    if (puntos2 == 15000):
        #imprimir jugador2 gana
        #cerrar ventana1
        NuevaVentana2()

def moverCarros5():
    global p, q, n, m, y,ventana5,canvas5,imagenC3,imagenC4,imagenC7,imagenC8,yA,yB,limite,retroceso,w,e,s,r,k,k1,k2,s2,w2,s3,w3,imagenC5,imagenC6,x,Fuel1,Fuel2
    global xm1, ym1, xm2, ym2, imagenM1, imagenM2, imagenMancha, k3, k4, k5, k6, xg1, yg1, xg2, yg2, imagenG1, imagenG2, imagenGas, puntos, puntos2

    
    s = random.randint(230,380) #x de carroC3
    w = random.randint(880,1040) #x de carroC4
    s2 = random.randint(230,380) #x de carroC5
    w2 = random.randint(880,1040) #x de carroC6
    s3 = random.randint(250,350) #x de carroC5
    w3 = random.randint(800,1040)

    xm1 = random.randint(230,380)
    ym1 = 0

    xm2 = random.randint(880,1040)
    ym2 = 0

    xg1 =  random.randint (230, 380)
    yg1 = 0

    xg2 = random.randint (880, 1040)
    yg2 = 0
    
    if(canvas5.coords(imagenC5)[1] == 890.0):
        canvas5.move(imagenC5,0,-100)
        
    # Enemigo 1
    if (k>400):
        k=0
        imagenC3 = canvas5.create_image(s,r, image = imagenCarro3)
        imagenC4 = canvas5.create_image(w,e, image = imagenCarro3)

    k = k + 2
    canvas5.move(imagenC3,0,4)
    canvas5.move(imagenC4,0,4)

    distxC3C1 = (canvas5.coords(imagenC3)[0] - canvas5.coords(imagenC1)[0])**2
    distyC3C1 = (canvas5.coords(imagenC3)[1] - canvas5.coords(imagenC1)[1])**2
    distEuclC3C1 = sqrt(distxC3C1+distyC3C1)
    
    #print("C3 ", canvas1.coords(imagenC3))
    #print("C1 ", canvas1.coords(imagenC1))
    #print("distx ",  distxC3C1, " disty ",  distyC3C1, "euclidiana ", sqrt(distxC3C1+distyC3C1))
    
    if(distEuclC3C1 <= 55):
        Fuel1 -= 10
       # print("colision ")

    ################ colision 2 ################
    ############################################

    distxC5C1 = (canvas5.coords(imagenC5)[0] - canvas5.coords(imagenC1)[0])**2
    distyC5C1 = (canvas5.coords(imagenC5)[1] - canvas5.coords(imagenC1)[1])**2
    distEuclC5C1 = sqrt(distxC5C1+distyC5C1)
    if (distEuclC5C1 <= 60):
        Fuel1 -= 10
        canvas5.coords(imagenC1)[0] = canvas5.coords(imagenC1)[0] - 10
        
       # print("C5 ", canvas1.coords(imagenC5))
      #  print("C1 ", canvas1.coords(imagenC1))
     #   print("distx ",  distxC5C1, " disty ",  distyC5C1, "euclidiana ", sqrt(distxC5C1+distyC5C1))
    #    print("colision 2")
     #ventana1.after(60, moverCarros)


    # Enemigo 2
    if (k1>565):
        k1=0
        imagenC5 = canvas5.create_image(s2,r, image = imagenCarro4)
        imagenC6 = canvas5.create_image(w2,e, image = imagenCarro4)

    k1 = k1 + 2
    #print(canvas1.coords(imagenC5)[0])
    if(canvas5.coords(imagenC5)[0]== 390.0):
        x=1
    if(canvas5.coords(imagenC5)[0]== 225.0):
        x=0
    if(canvas5.coords(imagenC6)[0]== 1040.0):
        y=1
    if(canvas5.coords(imagenC6)[0]== 873.0):
        y=0
    if(y==0):
        canvas5.move(imagenC6,1,2)
    else:
        canvas5.move(imagenC6,-1,2)        
    if(x==0):
        canvas5.move(imagenC5,1,2)
    else:
        canvas5.move(imagenC5,-1,2)
        canvas5.coords(imagenC6)
    ventana5.after(60, moverCarros5)

    # Enemigo 3

    if(k2>580):
        k2 = 0
        imagenC7 = canvas5.create_image(s3,r, image = imagenCarro5)
        imagenC8 = canvas5.create_image(w3,e, image = imagenCarro5)
    k2 = k2 + 2
        
    canvas5.move(imagenC7,0,2)
    canvas5.move(imagenC8,0,2)
    #print(canvas1.coords(imagenC7)[1])
#    if(canvas1.coords(imagenC7)[1] > 620.0):
        #print("coso")
 #       canvas1.move(imagenC7,0,2)
        
    #if(canvas1.coords(imagenC7)[1]==canvas1.coords(imagenC1)[1]):
      #  canvas1.move(imagenC7,0,canvas1.coords(imagenC7)[1])



    #manchas de aceite quitan puntos y gasolina 
    if (k3 > 500):
        k3 = 0
        imagenM1 = canvas5.create_image(xm1, ym1, image = imagenMancha)

    k3 = k3 + 2
    canvas5.move (imagenM1, 0, 3)

    #colision con aceite player 1
    ##########################
    distxM1C1 = (canvas5.coords(imagenM1)[0] - canvas5.coords(imagenC1)[0])**2
    distyM1C1 = (canvas5.coords(imagenM1)[1] - canvas5.coords(imagenC1)[1])**2
    distEuclM1C1 = sqrt(distxM1C1+distyM1C1)
    if (distEuclM1C1 <= 60):
        Fuel1 -= 100
        puntos -= 10
        canvas5.move(imagenC1, 1, 1)
        p = p + 1
        
        
    if(k4 > 500):
        k4 = 0
        imagenM2 = canvas5.create_image(xm2, ym2, image = imagenMancha)
    k4 = k4 + 2
    canvas5.move (imagenM2,0,3)

    #colision con aceite player 2
    #############################
    distxM2C2 = (canvas5.coords(imagenM2)[0] - canvas5.coords(imagenC2)[0])**2
    distyM2C2 = (canvas5.coords(imagenM2)[1] - canvas5.coords(imagenC2)[1])**2
    distEuclM2C2 = sqrt(distxM2C2+distyM2C2)
    if (distEuclM2C2 <= 60):
        Fuel2 -= 100
        puntos2 -= 10
        canvas5.move(imagenC2, 1, 1)
        n = n + 1

    #gasolina
    if (k5 > 400):
        k5 = 0
        imagenG1 = canvas5.create_image(xg1, yg1, image = imagenGas)
    k5 = k5 + 2
    canvas5.move (imagenG1, 0, 3)

    #colision con gasolina player 1
    ##########################
    distxG1C1 = (canvas5.coords(imagenG1)[0] - canvas5.coords(imagenC1)[0])**2
    distyG1C1 = (canvas5.coords(imagenG1)[1] - canvas5.coords(imagenC1)[1])**2
    distEuclG1C1 = sqrt(distxG1C1+distyG1C1)
    if (distEuclG1C1 <= 60):
        Fuel1 += 250
        k5 = 400
        canvas5.delete(imagenG1)
    
    if (k6 > 400):
        k6 = 0
        imagenG2 = canvas5.create_image(xg2, yg2, image = imagenGas)
    k6 = k6 + 2
    canvas5.move(imagenG2, 0, 3)

    if (Fuel1 == 0):
        #imagen gameover gana jugador 2
        print ("jugador2")

    if (Fuel2 == 0):
        #imagen gameover gana jugador 1
        print("jugador1")

def key5(event):
    """
    """
    global e1,imagenC1,imagenC2,imagenC3,imagenC7,imagenCarro5,p,q,m,n,canvas5,imagenCarro1,tecla,ventana5,imagenCarro2,imagenEx,limite,w,q1,imagenC7,Fuel1,Fuel2
    tecla = repr(event.char)

    if(tecla == "'w'"):
        Fuel1 -= 10
        if(q < 500): 
            canvas5.delete(imagenC1)
            q = q - 10
            imagenC1 = canvas5.create_image(p,q,image=imagenCarro1)

    if(tecla == "'s'"):
        Fuel1 -= 10
        if(q > 0): 
            canvas5.delete(imagenC1)
            q = q + 10
            imagenC1 = canvas5.create_image(p,q,image=imagenCarro1)

    if(tecla == "'d'"):
        Fuel1 -= 10
        canvas5.move(imagenC7,5,0)
        if(p < 380):
            canvas5.delete(imagenC1)
            #canvas1.delete(imagenC7)
            p = p + 10
            imagenC1 = canvas5.create_image(p,q,image=imagenCarro1)
            #imagenC7 = canvas1.create_image(p,e1,image=imagenCarro5)
            if (p == 380):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(380,q,image=imagenEx)
##                ventana1.after(200,timee)             
##        else:
##            canvas1.delete(imagenC1)
##            p = p - 10
##            imagenC1 = canvas1.create_image(p,q, image=imagenCarro1)
##            

    if(tecla == "'a'"):
        Fuel1 -= 10
        canvas5.move(imagenC7,-5,0)
        if(p > 230):
            canvas5.delete(imagenC1)
            p = p - 10
            imagenC1 = canvas5.create_image(p,q,image=imagenCarro1)
            if ( p == 230):
                Fuel1 -= 100
##                canvas1.delete(imagenC1)
##                imagenEx1 = canvas1.create_image(230,q,image=imagenEx)
##                ventana1.after(1,timee)
##                canvas1.delete(imagenEx)
                
##        else:
##            canvas1.delete(imagenC1)
##            p = p + 10
##            imagenC1 = canvas1.create_image(p,q,image=imagenCarro1)

    if(tecla == "'y'"):
        Fuel2 -= 10
        if(m < 500):
            canvas5.delete(imagenC2)
            m = m - 10
            imagenC2 = canvas5.create_image(n,m,image=imagenCarro2)

    if(tecla == "'h'"):
        Fuel2 -= 10
        if(m > 0):
            canvas5.delete(imagenC2)
            m = m + 10
            imagenC2 = canvas5.create_image(n,m,image=imagenCarro2)

    if(tecla == "'g'"):
        if(n > 880):
            canvas5.delete(imagenC2)
            n = n - 10
            imagenC2 = canvas5.create_image(n,m,image=imagenCarro2)
            if(p==880):
                canvas1.delete(imagenC2)
                imagenEx1 = canvas5.create_image(880,q,image=imagenEx)
                ventana5.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n + 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)

    if(tecla == "'j'"):
        if(n < 1040):
            canvas5.delete(imagenC2)
            n = n + 10
            imagenC2 = canvas5.create_image(n,m,image=imagenCarro2)
            if(p==1040):
                canvas1.delete(imagenC2)
                imagenEx1 = canvas5.create_image(1040,450, image = imagenEx)
                ventana5.after(200,timee) 
##        else:
##            canvas1.delete(imagenC2)
##            n = n - 10
##            imagenC2 = canvas1.create_image(n,m,image=imagenCarro2)


def timee():
    time.sleep(100)
    
# Se va a crear la imagen
imagen = PhotoImage(file="Menu1.png")
imagenP = Label(ventana, image = imagen).place(x = 0, y  = 0)

# Se va a crear un campo de texto para Jugador 1
lblJugador1=Label(text="Jugador 1: ",font=("Arial",12)).place(x=100,y=350)
entrada1=StringVar()
txtJugador1=Entry(ventana,textvariable=entrada1).place(x=200,y=350)

# Se va a crear un campo de texto para Jugador 2
lblJugador2=Label(text="Jugador 2: ",font=("Arial",12)).place(x=100,y=400)
entrada2=StringVar()
txtJugador2=Entry(ventana,textvariable=entrada2).place(x=200,y=400)

# Se va a crear botones
btnNivel1=Button(ventana,text="Nivel 1",font=("Arial",12),command=NuevaVentana1).place(x=100,y=450)
btnNivel2=Button(ventana,text="Nivel 2",font=("Arial",12),command=NuevaVentana2).place(x=200,y=450)
btnNivel3=Button(ventana,text="Nivel 3",font=("Arial",12),command=NuevaVentana3).place(x=300,y=450)
btnNivel4=Button(ventana,text="Nivel 4",font=("Arial",12),command=NuevaVentana4).place(x=400,y=450)
btnNivel5=Button(ventana,text="Nivel 5",font=("Arial",12),command=NuevaVentana5).place(x=500,y=450)


ventana.mainloop()
